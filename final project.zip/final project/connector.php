<?php
    if($_SERVER['REQUEST_METHOD']=='POST')
    {
        
    // Connect to database
    require("/home/dnguyen/credits/credentials.php");
    $email   = $_POST['email'];
    $error = false; 
    $connector = "";
    $hide = true;
	
    //validate and trim first email

        if (filter_var($_POST["email"], FILTER_VALIDATE_EMAIL) == true)
        {
		$email = strip_tags($email);
		$email = htmlspecialchars($email);
		$email = mysqli_real_escape_string($dbc, trim($_POST["email"]));
        }
        else
        {
        	$error = true;
            	$errEmail = "Please enter a valid email.";
        }
        
    
        //If no errors, make and run query to insert data into database
        if(!error)
        {
        	$q = "SELECT connector, email FROM connectors WHERE email ='$email'";
            	$result = mysqli_query($dbc, $q);
           	$count  = mysqli_num_rows($result);
 
		if($count == 1)
		{
			$hide = false;
			$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
			$connector = $row['connector'];		
		} 
		else
		{
			$errMessage = "We did not find you in our database";
		}
    	}
    	
    }
?>
<!DOCTYPE html>
<html lang="en">
<head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Connector view</title>
    <!-- BOOTSTRAP + FONT-AWESOME -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    
    <!-- CUSTOMIZE CSS -->
    <link href="css/connector.css" rel="stylesheet" type="text/css">
    <link href="css/layout.css" rel="stylesheet" type="text/css">
    
	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
    	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.13/css/jquery.dataTables.css">
	<script type="text/javascript" charset="utf8" src="//cdn.datatables.net/1.10.13/js/jquery.dataTables.js"></script>

	
	<script>
		$(document).ready( function () {
	    		$('#connector').DataTable();
		} );
	</script>
    
</head>

<body>
    <div class="container-fluid">
        <div class="row description">
            <h3><a href="http://dnguyen.greenrivertech.net/finalDuck/">Connecting students <i class="fa fa-puzzle-piece" aria-hidden="true"></i></a></h3>
        </div>
    </div>
    
    <?php if (!$hide){ ?>
    <div class="container" id="form_body">
        <!-- START FORM -->
        <form method="post" action="connector.php" role="form">
        	<legend style="color:#28B463"><i class="fa fa-user" aria-hidden="true"></i> Connector information</legend>
        	
		<div class="input-group" for="email">
			<span class="input-group-addon"><i class="fa fa-envelope-o" aria-hidden="true"></i></span>
			<input type="email" name="email" class="form-control" id="connector-email" placeholder="Enter your email" required/>
		</div>
		
		<br>
		
		<div class="form-group">
			<!-- <span class="text-danger"><?php echo ',<pre>'; print_r($error); echo '</pre>';?></span> -->
			<button type="submit" class="btn btn-warning text-center">Connect me!</button>
		</div>
        </form>
    </div>
    <?php } ?>
    <!-- START STUDENT TABLE -->
	<?php		#Start PHP Code

	//Make query
	$q  = "SELECT * FROM student";
	$r = @mysqli_query($dbc, $q);
	$space = " ";
	//If query ran ok, display data
	if($r)
	{
		echo "
		<div class='container-fluid table-area'>
			<div class='row'>
		<table id='connector' class='table table-striped table-hover'>
                <thead>
                    <tr>
                        <th>Student name</th>
                        <th>Email</th>
                        <th>Date</th>
                        <th>Interested skills</th>
                        <th>Message</th>
                    </tr>
                </thead>
				<tbody>";
						if (mysqli_num_rows($r) > 0)
						{
							while($row = mysqli_fetch_array($r, MYSQLI_ASSOC))
							{
								echo '
								<tr>
									<td>' . $row['name'] . '</td>
									<td>' . $row['email'] . '</td>
									<td>' . $row['date'] . '</td>
									<td>' . $row['coreF']. $row['coreJ']. $row['frontE']. $row['lstack']. $row['mstack']. $row['jstack'].
										$row['algos']. $row['mobile']. $row['dataA']. $row['systemP'].'</td>
									<td>' . $row['message'] . '</td>
								</tr>';
							}
						}
						
			echo "
				</tbody>
			</table>
		</div>
		</div>";
			
		//close database connection
		mysqli_close($dbc);						
	}
	?>

    <footer class="footer">
    <nav class="navbar navbar-inverse">
    <div class="container-fluid">
            <ul class="nav navbar-nav navbar-left">
                <li>
                    <a href="#">
                       made by<img src="img/duck.png" id="ducky">
                    </a> 
                </li>
            </ul>
    </div>
    </nav>
    </footer>

</body>
</html>