<?php
    if($_SERVER['REQUEST_METHOD']=='POST')
    {
        
    // Connect to database
    require("/home/dnguyen/credits/credentials.php");
    $name    = $_POST['name'];
    $email   = $_POST['email'];
    $date    = $_POST['date'];
    $coreF   = $_POST['coreF'];
    $coreJ   = $_POST['coreJ'];
    $fontE   = $_POST['fontE'];
    $lstack  = $_POST['lstack'];
    $mstack  = $_POST['mstack'];
    $jstack  = $_POST['jstack'];
    $algos   = $_POST['algos'];
    $mobile  = $_POST['mobile'];
    $dataA   = $_POST['dataA'];
    $systemP = $_POST['systemP'];
    $message = $_POST['message'];
    
    // annoying checkboxes 
    $s;
    $s1;
    $s2;
    $s3;
    $s4;
    $s5;
    $s6;
    $s7;
    $s8;
    $s9;
     

    //validate and trim first name
        if(isset($_POST["name"]))
        {
            $name = mysqli_real_escape_string($dbc, trim($_POST["name"]));
        }
        else
        {
            $errors[] = "Please enter your first name.";
        }

        if (filter_var($_POST["email"], FILTER_VALIDATE_EMAIL) == true)
        {
            $email = strip_tags($email);
            $email = htmlspecialchars($email);
            $email = mysqli_real_escape_string($dbc, trim($_POST["email"]));
        }
        else
        {
            $errors[] = "Please enter a valid email.";
        }
        
        
        if(isset($_POST['coreF']) && $_POST['coreF'] == '1') 
        {
            $s = "Core Front-End";
        }
        
        if(isset($_POST['coreJ']) && $_POST['coreJ'] == '1') 
        {
            $s1 = "Core Java";
        }

        if(isset($_POST['frontE']) && $_POST['frontE'] == '1') 
        {
            $s2 = "Front-End";
        }

        if(isset($_POST['lstack']) && $_POST['lstack'] == '1') 
        {
            $s3 = "LAMP Stack";
        }

        if(isset($_POST['mstack']) && $_POST['mstack'] == '1') 
        {
            $s4 = "Microsoft Stack";
        }

        if(isset($_POST['jstack']) && $_POST['jstack'] == '1') 
        {
            $s5 = "JavaScript Stack";
        }

        if(isset($_POST['algos']) && $_POST['algos'] == '1') 
        {
            $s6 = "Algorithms";
        }

        if(isset($_POST['mobile']) && $_POST['mobile'] == '1') 
        {
            $s7 = "Mobile";
        }

        if(isset($_POST['dataA']) && $_POST['dataA'] == '1') 
        {
            $s8 = "Data Analysis";
        }

        if(isset($_POST['systemP']) && $_POST['systemP'] == '1') 
        {
            $s9 = "System Programming";
        }
        
        if($_POST['message'])
        {   
            $message = strip_tags($message);
            $message = htmlspecialchars($message);
            $message = mysqli_real_escape_string($dbc, trim($_POST["message"]));
        }
        else
        {
            $message = "no message";
        }

        //If no errors, make and run query to insert data into database
        if(empty($errors))
        {
        	echo"querying";
            //Make query
            $q = "INSERT INTO student (name, email, coreF, coreJ, frontE, lstack, mstack, jstack, algos, mobile, dataA, systemP, message)
                    VALUES ('$name', '$email', '$s', '$s1', '$s2', '$s3', '$s4', '$s5', '$s6', '$s7', '$s8', '$s9', '$message')";
    
            //Run query
            $r = @mysqli_query($dbc, $q);
            
            //If query ran ok, print message
            if($r)
            {
                $success = "information sent!";
                
                echo '<script> setTimeout(function(){ window.location.href="http://dnguyen.greenrivertech.net/finalDuck/index.html"; }, 2000);</script>';
            }
            
        } 
        else  //Form is not filled out correctly
        {
            echo "<div class='error'><h3>Error!</h3>
            <p>The following error(s) occured: <br />";
            
            foreach($errors as $msg)
            {
                //print each error
                echo " - $msg<br />";
            }
            echo "</div>";
        }
    }

?>
<!DOCTYPE html>
<html lang="en">
<head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Student view</title>
    <!-- BOOTSTRAP + FONT-AWESOME -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    
    <!-- CUSTOMIZE CSS -->
    <link href="css/student.css" rel="stylesheet" type="text/css">
    <link href="css/layout.css" rel="stylesheet" type="text/css">
    
</head>

<body>
    <div class="container-fluid">
        <div class="row description">
            <h3><a href="http://dnguyen.greenrivertech.net/finalDuck/">Connecting students <i class="fa fa-puzzle-piece" aria-hidden="true"></i></a></h3>
        </div>
    </div>
    
    <div class="container" id="form_body">
        <!-- START FORM -->
        <form method="post" action="student.php" role="form">
            <div class="form-group">
            <legend style="color:#28B463"><i class="fa fa-info-circle" aria-hidden="true"></i> Student information</legend>
            <div class="input-group" for="name">
                <span class="input-group-addon"><i class="fa fa-user" aria-hidden="true"></i></span>
                <input type="text" name="name" class="form-control" id="student-name" placeholder="Enter your name" required/>
            </div>
            
            <br>

            <div class="input-group" for="email">
                <span class="input-group-addon"><i class="fa fa-envelope-o" aria-hidden="true"></i></span>
                <input type="email" name="email" class="form-control" id="student-email" placeholder="Enter your email" required/>
            </div>
            </div>
            
            <br>
            
            <fieldset class="form-group">
                <legend style="color:#28B463"><i class="fa fa-star" aria-hidden="true"></i> Select skills applicable to your interests:</legend>
                
                <!-- ==== LEFT SIDE ==== -->
                <div class="col-sm-6">
                    <!-- CORE FRONT-END -->
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" name="coreF" class="form-check-input" value="1">
                            Core Front-End <small class="text-muted">(HTML, CSS, JavaScript)</small>
                        </label>
                    </div>
                    
                    <!-- FRONT-END FRAMEWORKS -->
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" name="frontE" class="form-check-input" value="1">
                            Front-End Frameworks <small class="text-muted">(Bootstrap, JQuery, Sass, Less)</small>
                        </label>
                    </div>
                    
                    <!-- LAMP STACK -->
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" name="lstack" class="form-check-input" value="1">
                            LAMP Stack <small class="text-muted">(emphasis on PHP and MySQL)</small>
                        </label>
                    </div>
                    
                    <!-- MICROSFOT STACK -->
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" name="mstack" class="form-check-input" value="1">
                            Microsoft Stack <small class="text-muted">(SQL Server, .NET, C&#35;, ASP, etc.)</small>
                        </label>
                    </div>
                    
                    <!-- JAVASCRIPT STACK -->
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" name="jstack"class="form-check-input" value="1">
                            JavaScript Stack <small class="text-muted">(JavaScript on client + server&#59; Node, Angular, React)</small>
                        </label>
                    </div>
                </div>
                
                <!-- ==== RIGHT SIDE ==== -->
                <div class="col-sm-6">
                    <!-- ALGORITHMS -->
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" name="algos" class="form-check-input" value="1">
                            Algorithms <small class="text-muted">(any language)</small>
                        </label>
                    </div>
                    
                    <!-- MOBILE TECHNOLOGIES -->
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" name="mobile" class="form-check-input" value="1">
                            Mobile Technologies <small class="text-muted">(Android, IOS)</small>
                        </label>
                    </div>
                    
                    <!-- -->
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" name="dataA" class="form-check-input" value="1">
                            Data Analysis &frasl; Database Programming <small class="text-muted">(SQL)</small>
                        </label>
                    </div>
                    
                    <!-- CORE JAVA -->
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" name="coreJ" class="form-check-input" value="1">
                            Core Java &frasl; Java Frameworks <small class="text-muted">(Swing, Spring, etc.)</small>
                        </label>
                    </div>
                    
                    <!-- SYSTEM PROGRAMMING -->
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" name="systemP" class="form-check-input" value="1">
                            Systems Programming &frasl; High Performance Computing
                        </label>
                    </div>
                </div>
            
            </fieldset>
            <br>
            <!-- TEXTBOX -->
            <div class="form-group">
                <label for="other-message" style="color:#28B463"><i class="fa fa-comment" aria-hidden="true"></i> Other interests or comments <small class="text-muted">(optional)</small></label>       
                <textarea class="form-control" id="other-message" name="message" placeholder="Enter your message..." rows="5"></textarea>
            </div>
            
            <div class="form-group">
	            <span class="text-success"><?php echo '$success';?></span>
	            <button type="submit" class="btn btn-warning text-center">Done done!</button>
            </div>
        </form>
    </div>
    
    <footer class="footer">
    <nav class="navbar navbar-inverse">
    <div class="container-fluid">
            <ul class="nav navbar-nav navbar-left">
                <li>
                    <a href="#">
                       made by<img src="img/duck.png" id="ducky">
                    </a> 
                </li>
            </ul>
    </div>
    </nav>
    </footer>
    

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>